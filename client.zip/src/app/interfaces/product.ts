export interface Product {
    name: string,
    slug: string,
    price: number,
    category: string,
    brand: string,
    productImg: any
}
