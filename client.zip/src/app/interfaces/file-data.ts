export interface FileData {
    folderPath: string;
    fileName: string;
    file: File;
  }